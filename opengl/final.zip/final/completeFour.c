// Using OpenGL, write a program that allows interactive translation/rotation/scaling of polygons via user input.
// The program allows the user to translate the polygon by pressing the 't' key.
// The program allows the user to rotate the polygon by pressing the 'r' key.
// The program allows the user to scale the polygon by pressing the 's' key.
// The program allows the user to quit the program by pressing the 'q' key.
// The program allows the user to change the color of the polygon by pressing the 'c' key.
// The program allows the user to change the fill color of the polygon by pressing the 'f' key.
// The program allows the user to change the width of the polygon by pressing the 'w' key.
// The program allows the user to change the fill color of the polygon by pressing the 'f' key.
// The program allows the user to change the fill color of the polygon by pressing the 'f' key.
// The program allows the user to change the fill color of the polygon by pressing the 'f' key.
// The program allows the user to change the fill color of the polygon by pressing the 'f' key.

#include <GL/glut.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <time.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>
#include <stdbool.h>

#define MAXPOINTS 1000

typedef struct {
    int x;
    int y;
} Point;

typedef struct {
    Point points[MAXPOINTS];
    int numPoints;
} Polygon;

typedef struct {
    int r;
    int g;
    int b;
} Color;

typedef struct {
    int width;
    Color color;
    Color fillColor;
    Polygon polygon;
} PolyData;

PolyData polyData;

void initPolyData() {
    polyData.width = 1;
    polyData.color.r = 0;
    polyData.color.g = 0;
    polyData.color.b = 0;
    polyData.fillColor.r = 255;
    polyData.fillColor.g = 255;
    polyData.fillColor.b = 255;
    polyData.polygon.numPoints = 0;
}


void drawPolygon(Polygon polygon) {
    glBegin(GL_LINE_LOOP);
    for (int i = 0; i < polygon.numPoints; i++) {
        glVertex2i(polygon.points[i].x, polygon.points[i].y);
    }
    glEnd();
}

void drawPolygons() {
    glColor3ub(polyData.color.r, polyData.color.g, polyData.color.b);
    glLineWidth(polyData.width);
    drawPolygon(polyData.polygon);
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT);
    drawPolygons();
    glFlush();
}

void mouse(int button, int state, int x, int y) {
    if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN) {
        if (polyData.polygon.numPoints < MAXPOINTS) {
            polyData.polygon.points[polyData.polygon.numPoints].x = x;
            polyData.polygon.points[polyData.polygon.numPoints].y = 500 - y;
            polyData.polygon.numPoints++;
        }
        glutPostRedisplay();
    }
}

void keyboard(unsigned char key, int x, int y) {
    switch (key) {
        case 'c':
            printf("Enter the color (r g b): ");
            scanf("%d %d %d", &polyData.color.r, &polyData.color.g, &polyData.color.b);
            break;
        case 'f':
            printf("Enter the fill color (r g b): ");
            scanf("%d %d %d", &polyData.fillColor.r, &polyData.fillColor.g, &polyData.fillColor.b);
            break;
        case 'w':
            printf("Enter the width: ");
            scanf("%d", &polyData.width);
            break;
        case 'q':
            exit(0);
            break;
    }
    glutPostRedisplay();
}

void init() {
    glClearColor(1.0, 1.0, 1.0, 1.0);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(0.0, 500.0, 0.0, 500.0);
}

int main(int argc, char **argv) {
    initPolyData();
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(500, 500);
    glutInitWindowPosition(100, 100);
    glutCreateWindow("Polygon");
    glutDisplayFunc(display);
    glutMouseFunc(mouse);
    glutKeyboardFunc(keyboard);
    init();
    glutMainLoop();
    return 0;
}




