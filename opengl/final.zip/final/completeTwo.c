// Write an OpenGL program that allows interactive creation of polygons via mouse input.
// The polygon is drawn in one color and filled with another color.
// The program allows the user to complete the polygon by pressing the right mouse button.
// The program allows the user to clear the screen by pressing the middle mouse button.
// The program allows the user to quit the program by pressing the left mouse button.
// The program allows the user to change the color of the polygon by pressing the 'c' key.
// The program allows the user to change the fill color of the polygon by pressing the 'f' key.
// The program allows the user to change the width of the polygon by pressing the 'w' key.
// The program allows the user to change the fill color of the polygon by pressing the 'f' key.
// The program allows the user to change the fill color of the polygon by pressing the 'f' key.
// The program allows the user to change the fill color of the polygon by pressing the 'f' key.

#include <GL/glut.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <time.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>
#include <stdbool.h>

#define MAXPOINTS 1000

typedef struct {
    int x;
    int y;
} Point;

typedef struct {
    Point points[MAXPOINTS];
    int numPoints;
} Polygon;

typedef struct {
    int r;
    int g;
    int b;
} Color;

typedef struct {
    int width;
    Color color;
    Color fillColor;
    Polygon polygon;
} PolyData;

PolyData polyData;

void initPolyData() {
    polyData.width = 1;
    polyData.color.r = 0;
    polyData.color.g = 0;
    polyData.color.b = 0;
    polyData.fillColor.r = 255;
    polyData.fillColor.g = 255;
    polyData.fillColor.b = 255;
    polyData.polygon.numPoints = 0;
}

void clearScreen() {
    glClear(GL_COLOR_BUFFER_BIT);
    glFlush();
}

void drawLine(Point p1, Point p2) {
    glColor3f((float)polyData.color.r/255.0, (float)polyData.color.g/255.0, (float)polyData.color.b/255.0);
    glLineWidth(polyData.width);
    glBegin(GL_LINES);
        glVertex2i(p1.x
        , p1.y);
        glVertex2i(p2.x
        , p2.y);
    glEnd();
    glFlush();
}

void drawPolygon(Polygon polygon) {
    glColor3f((float)polyData.color.r/255.0, (float)polyData.color.g/255.0, (float)polyData.color.b/255.0);
    glLineWidth(polyData.width);
    glBegin(GL_LINE_LOOP);
    for (int i = 0; i < polygon.numPoints; i++) {
        glVertex2i(polygon.points[i].x
        , polygon.points[i].y);
    }
    glEnd();
    glFlush();
}

void drawFilledPolygon(Polygon polygon) {
    glColor3f((float)polyData.fillColor.r/255.0, (float)polyData.fillColor.g/255.0, (float)polyData.fillColor.b/255.0);
    glBegin(GL_POLYGON);
    for (int i = 0; i < polygon.numPoints; i++) {
        glVertex2i(polygon.points[i].x
        , polygon.points[i].y);
    }
    glEnd();
    glFlush();
}

void drawPolygons() {
    drawPolygon(polyData.polygon);
    drawFilledPolygon(polyData.polygon);
}

void mouse(int button, int state, int x, int y) {
    if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN) {
        exit(0);
    }
    if (button == GLUT_MIDDLE_BUTTON && state == GLUT_DOWN) {
        clearScreen();
    }
    if (button == GLUT_RIGHT_BUTTON && state == GLUT_DOWN) {
        drawPolygons();
    }
}

void keyboard(unsigned char key, int x, int y) {
    if (key == 'c') {
        printf("Enter the color of the polygon (r g b): ");
        scanf("%d %d %d", &polyData.color.r, &polyData.color.g, &polyData.color.b);
    }
    if (key == 'f') {
        printf("Enter the fill color of the polygon (r g b): ");
        scanf("%d %d %d", &polyData.fillColor.r, &polyData.fillColor.g, &polyData.fillColor.b);
    }
    if (key == 'w') {
        printf("Enter the width of the polygon: ");
        scanf("%d", &polyData.width);
    }
}

void mouseMotion(int x, int y) {
    if (polyData.polygon.numPoints < MAXPOINTS) {
        polyData.polygon.points[polyData.polygon.numPoints].x = x;
        polyData.polygon.points[polyData.polygon.numPoints].y = 500 - y;
        polyData.polygon.numPoints++;
    }
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT);
    glFlush();
}

void init() {
    glClearColor(1.0, 1.0, 1.0, 0.0);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(0.0, 500.0, 0.0, 500.0);
}

int main(int argc, char** argv) {
    initPolyData();
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(500, 500);
    glutInitWindowPosition(100, 100);
    glutCreateWindow("Polygon");
    glutDisplayFunc(display);
    glutMouseFunc(mouse);
    glutKeyboardFunc(keyboard);
    glutMotionFunc(mouseMotion);
    init();
    glutMainLoop();
    return 0;
}

