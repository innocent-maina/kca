import java.util.Scanner;

public class While12 {
  public static void main(String[] args) {
    Scanner myScanner = new Scanner(System.in);
    int i = 1;
    while (i <= 25) {
      System.out.println("God bless Kenya");
      i++;
    }
  }
}
