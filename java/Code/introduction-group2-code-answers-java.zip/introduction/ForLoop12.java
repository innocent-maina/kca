import java.util.Scanner;

public class ForLoop12 {
  public static void main(String[] args) {
    Scanner myScanner = new Scanner(System.in);
    int i = 1;
    for (i = 1; i <= 25; i++) {
      System.out.println("God bless Kenya");
    }
  }
}
